The DesktopDemo project demonstrates API functionality in the Java SE 6 
(Mustang) product. You must build the DesktopDemo project using that product. 
Set the environment variable JAVA_HOME to your JDK's root directory before 
using ant to build or run this project.

To build the project from its source:
    ant dist

To run the project:
    ant run

